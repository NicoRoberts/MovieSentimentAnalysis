# -*- coding: utf-8 -*-
"""
Created on Fri Aug  6 16:15:40 2021

@author: Nicol
"""

#Nicolas Roberts
#8/6/21
#TCSS 456
#Final Project

"""
Final NLP project option 1, Sentiment Analysis
"""
import os
import tweepy as tw
import pandas as pd
import sys
import re
import string
from nltk.corpus import stopwords
from BagOfWords import *
from CNN import *

def main(): #Driver
    filename = "SuicideSquadReviews.txt"
    outputFile = "Readme.txt"
    file = open(filename, "w")
    print("Retrieving 50 most recent tweets on 'Suicide Squad Movie Review'. Please be patient.")   
    getTwitterMovieReviews(file)
    file.close()
    print("\nTraining Bag of Words model...\n")
    executeBagOfWords(filename, outputFile)
    print("\nTraining Convolutional Neural Networks Model...\n")
    executeCNN(filename, outputFile)
    print("Training complete. See output file for results.")
    
    
    
    
def getTwitterMovieReviews(f):
    print("Start of program\n")
    consumer_key= 'KnUlN9kEQ7gJdDiVp8oNE1Wg2'
    consumer_secret= 'mRtOVvdiZIzqwdxebqo47WmOBGBvWjIwtZvufDU2E84vlm5QV4'
    access_token= '1027293645676769280-2heVzKV4eDN7LDv0Udtk8VkE8Ubj9m'
    access_token_secret= '6RdwPKQbgIX75EcsI3eovdsqhtomqUgsHWo4Lwa1lOwnM'
    
    auth = tw.OAuthHandler(consumer_key, consumer_secret)
    auth.set_access_token(access_token, access_token_secret)
    api = tw.API(auth, wait_on_rate_limit=True)
    
    # Define the search term and the date_since date as variables
    search_words = "suicide squad movie review" + " -filter:retweets"
    date_since = "2021-7-31"
    
    #tweets = api.search(q=search_words, result_type='popular', tweet_mode='extended')
    
    # Collect tweets   
    tweets = tw.Cursor(api.search,
                        q=search_words,
                        lang="en",
                        tweet_mode="extended",
                        since=date_since).items(50)
    
    

    #fc = open("SuicideSquadReviewsClean.txt", "w")
    
    # Iterate and print tweets
    count = 1
    for tweet in tweets:
        print("Cleaning tweet " + str(count) + " of 50")
        line = str(tweet.full_text.encode(sys.stdout.encoding, errors='replace'))
        cleanText(line, f)
        count += 1
        #f.write(string + '\n')                

    
def cleanText(theLine, file):
    # split into tokens by white space
    tokens = theLine.split()
    
    #remove b
    word = tokens[0]
    firstWordList = list(word)
    if(firstWordList[0] == 'b'):
        del firstWordList[0]
        newString = ''.join(firstWordList)
        tokens[0] = newString
  
    # prepare regex for char filtering
    re_punc = re.compile( '[%s]' % re.escape(string.punctuation))
    
    # remove punctuation from each word
    tokens = [re_punc.sub('', w) for w in tokens]
    # remove remaining tokens that are not alphabetic
    tokens = [word for word in tokens if word.isalpha()]
    
    #clean up URLs
    index = 0
    for i in range(0, len(tokens)):
        if (len(tokens[index]) > 4):
            if("https" in tokens[index]):
                del tokens[index]
                index-=1
        index+=1  
    # filter out stop words
   # stop_words = set(stopwords.words( 'english' ))
    #tokens = [w for w in tokens if not w in stop_words]
    
    
    line = ' '.join(tokens)
    file.write(line + '\n')
    

main() #call to driver to execute
