1.) Model Summary
Bag-of-Words Model:
_________________________________________________________________
Layer (type)                 Output Shape              Param #   
=================================================================
dense_3 (Dense)              (None, 50)                1288450   
_________________________________________________________________
dense_4 (Dense)              (None, 1)                 51        
=================================================================
Total params: 1,288,501
Trainable params: 1,288,501
Non-trainable params: 0
_________________________________________________________________


Convolutional Neural Networks Mode:
_________________________________________________________________
Layer (type)                 Output Shape              Param #   
=================================================================
embedding_1 (Embedding)      (None, 1317, 100)         2576800   
_________________________________________________________________
conv1d_1 (Conv1D)            (None, 1310, 32)          25632     
_________________________________________________________________
max_pooling1d_1 (MaxPooling1 (None, 655, 32)           0         
_________________________________________________________________
flatten_1 (Flatten)          (None, 20960)             0         
_________________________________________________________________
dense_3 (Dense)              (None, 10)                209610    
_________________________________________________________________
dense_4 (Dense)              (None, 1)                 11        
=================================================================
Total params: 2,812,053
Trainable params: 2,812,053
Non-trainable params: 0
_________________________________________________________________

2.) Epoch Results
Bag-of-Words Model:
Epoch 1/10
 - 2s - loss: 0.6915 - accuracy: 0.6044
Epoch 2/10
 - 1s - loss: 0.6815 - accuracy: 0.8744
Epoch 3/10
 - 1s - loss: 0.6631 - accuracy: 0.8183
Epoch 4/10
 - 1s - loss: 0.6350 - accuracy: 0.9039
Epoch 5/10
 - 1s - loss: 0.5981 - accuracy: 0.9356
Epoch 6/10
 - 2s - loss: 0.5569 - accuracy: 0.9444
Epoch 7/10
 - 1s - loss: 0.5135 - accuracy: 0.9433
Epoch 8/10
 - 1s - loss: 0.4676 - accuracy: 0.9561
Epoch 9/10
 - 1s - loss: 0.4249 - accuracy: 0.9606
Epoch 10/10
 - 1s - loss: 0.3849 - accuracy: 0.9678
Test Accuracy: 85.000002

Convolutional Neural Networks Mode:
Epoch 1/10
 - 24s - loss: 0.6899 - accuracy: 0.5289
Epoch 2/10
 - 23s - loss: 0.5260 - accuracy: 0.7561
Epoch 3/10
 - 24s - loss: 0.0667 - accuracy: 0.9911
Epoch 4/10
 - 23s - loss: 0.0051 - accuracy: 1.0000
Epoch 5/10
 - 23s - loss: 0.0020 - accuracy: 1.0000
Epoch 6/10
 - 23s - loss: 0.0013 - accuracy: 1.0000
Epoch 7/10
 - 23s - loss: 9.4069e-04 - accuracy: 1.0000
Epoch 8/10
 - 23s - loss: 7.3207e-04 - accuracy: 1.0000
Epoch 9/10
 - 23s - loss: 5.8598e-04 - accuracy: 1.0000
Epoch 10/10
 - 23s - loss: 4.8475e-04 - accuracy: 1.0000

3.) Performance Evalutation

Bag-of-Words Model:
Train Accuracy: 96.888888
Test Accuracy: 87.000000

Convolutional Neural Networks Mode:
Train Accuracy: 100.00
Test Accuracy: 87.00

4.) Sentiment Analysis results (50 tweets for each model appended to the end with each program run)

Bag-of-Words Model:
Review: [NEGROMANCER Movie Review Suicide Squad Hell to Pay is Way]
Sentiment: POSITIVE (50.850%)
Review: [FULL REVIEW The Suicide Squad movie MovieReview]
Sentiment: NEGATIVE (97.950%)
Review: [my letterboxd review of the suicide squad is up i hate that i use letterboxd now after i watch a movie]
Sentiment: NEGATIVE (99.920%)
Review: [In this episode of PodCapers Scott is joined by Francisco Andrade to talk about TheSuicideSquad Whats this Is this movie actually good PodernFamily review spoilers HarleyQuinn JamesGunn Bloodsport Peacemaker]
Sentiment: NEGATIVE (99.994%)
Review: [NowListeningnnfnnerds The Suicide Squad FN Movie]
Sentiment: POSITIVE (50.850%)
Review: [The Suicide Squad Movie Review TheSuicideSquad]
Sentiment: POSITIVE (50.850%)
Review: [JamesGunn can turn comic characters from the margins into cult movie heroes Career Russian roulette for Gunn and his squad has never seemed like suicide The whole comicbook galaxy is now under his changing guard We review DCComics TheSuicideSquad]
Sentiment: NEGATIVE (98.137%)
Review: [I Reads You IReadsYou Movie Review THE SUICIDE SQUAD]
Sentiment: POSITIVE (50.850%)
Review: [Review NEGROMANCER Movie Review Suicide Squad Hell to Pay is Way]
Sentiment: POSITIVE (50.850%)
Review: [this article just tells me you can write anything to justify anything and you dont even have to be compelling]
Sentiment: NEGATIVE (100.000%)
Review: [Blog The Highest Grossing Films That Critics Stand Give Suicide Squad Hope weekend saw the opening of The Suicide Squad the latest movie from DC Studios in the seemingly everlucrative comicbook movie era However audiences proved sluggish]
Sentiment: NEGATIVE (75.814%)
Review: [I finally posted my review for TheSuicideSquad check it out]
Sentiment: NEGATIVE (87.511%)
Review: [okay the suicide squad quick review from men good movie way better than the first one n FUNNY but also made me tear up n so dark amp sad amp wholesome but hilarious n margot robbie is everything n i believe im emotionally attached to a shark mutant creature thing]
Sentiment: POSITIVE (99.790%)
Review: [The Gunn cut Cocked and aimed This is TheSuicideSquad reloaded by GuardiansOfTheGalaxy legendary director JamesGunn So lets arm up and meet this team of recruits standing in front of the stars and stripes like JoelKinnamans Rick Flag We review]
Sentiment: NEGATIVE (100.000%)
Review: [James Gunns The Suicide Squad is a wild gory and fun movie with actual stakes and likeable characters End of review nnTheSuicideSquad]
Sentiment: POSITIVE (53.940%)
Review: [Movie ReviewnnThe Suicide Squad Bonkers wild an absolute blast]
Sentiment: POSITIVE (87.542%)
Review: [This isnt the DC studio I know Dark action adventure comedy with MargotRobbie JohnCena amp IdrisElba Flash Movie Review TheSuicideSquad via Moviejoltz]
Sentiment: NEGATIVE (99.992%)
Review: [Flash Movie Review The]
Sentiment: POSITIVE (50.850%)
Review: [The DoOver Review The Suicide Squad Muscatine]
Sentiment: POSITIVE (50.850%)
Review: [The DoOver Review The Suicide Squad Columbus]
Sentiment: POSITIVE (50.850%)
Review: [Movie Minute SUICIDE SQUAD Review by paulsalfen]
Sentiment: POSITIVE (50.850%)
Review: [James Gunns THE SUICIDE SQUAD Dont Get Too Attached But Enjoy The Ride Movie ReviewnnBy OGCinematichris TheSuicideSquad HBOMax]
Sentiment: POSITIVE (50.850%)
Review: [NEGROMANCER Movie Review Suicide Squad Hell to Pay is Way]
Sentiment: POSITIVE (50.850%)
Review: [A ridiculously fun over the top violent hilarious amp at times emotional action flick that further proves James Gunn really knows how to get it SuicideSquad jamesgunn DCEU MovieReview movie Review Letterboxd]
Sentiment: POSITIVE (99.978%)
Review: [The Suicide Squad proves that superhero films are at its best when it abandons the trytoohardtobefunny shtick and focus on the action that makes a superhero movie nnMy review of The Suicide Squad on Letterboxd]
Sentiment: NEGATIVE (94.855%)
Review: [FFP Reaction Review The Suicide SquadnnJoin BoneKingTV AdrianDudliness and DrRudeMD as they prepare for the impossible a fun SuicideSquad]
Sentiment: POSITIVE (96.104%)
Review: [In this episode of PodCapers Scott is joined by Francisco Andrade to talk about TheSuicideSquad Whats this Is this movie actually good PodernFamily review spoilers HarleyQuinn JamesGunn Bloodsport Peacemaker]
Sentiment: NEGATIVE (99.994%)
Review: [The Suicide Squad Bizarre Fun Movie Review YouTube]
Sentiment: POSITIVE (50.850%)
Review: [Why is John Cena better in The Suicide Squad than Fast amp Furious Join our discussion]
Sentiment: NEGATIVE (98.802%)
Review: [New VideonThe Suicide Squad Movie]
Sentiment: POSITIVE (50.850%)
Review: [Watch Th Best Bad Movie of All TimeThe Suicide Squad Review by TopTENN on YouTube]
Sentiment: POSITIVE (50.850%)
Review: [I Reads You IReadsYou Movie Review THE SUICIDE SQUAD]
Sentiment: POSITIVE (50.850%)
Review: [The Suicide squad Movie review Hindi via YouTubennMovieReview MovieReviews Review TheSuicideSquad movie Explainer]
Sentiment: NEGATIVE (99.739%)
Review: [The Suicide squad Movie review Hindi via YouTubennMovieReview MovieReviews Review TheSuicideSquad movie Explainer]
Sentiment: NEGATIVE (99.739%)
Review: [The Suicide Squad Movie Review via YouTube]
Sentiment: POSITIVE (93.022%)
Review: [Review NEGROMANCER Movie Review Suicide Squad Hell to Pay is Way]
Sentiment: POSITIVE (50.850%)
Review: [TheSuicideSquad is an awesome sequel to the original with a lot of heart emotion fun moments and a standout performance from MelchiorDaniela thanks to JamesGunnnnThe Suicide Squad is AWESOME Movie Review DCEU Movie Review A Ja via YouTube]
Sentiment: POSITIVE (100.000%)
Review: [TheSuicideSquad is an awesome sequel to the original with a lot of heart emotion fun moments and a standout performance from MelchiorDaniela thanks to JamesGunnnnThe Suicide Squad is AWESOME Movie Review DCEU Movie Review A Ja via YouTube]
Sentiment: POSITIVE (100.000%)
Review: [Did anybody like The Suicide SquadnnJudging from the responses I got on my those who didnt like it actually said they didnt like those who didnt watch it said they might want to watch those who like it hide]
Sentiment: NEGATIVE (100.000%)
Review: [Movie review Suicide Squad Overall I enjoyed it The action scenes are graphic at times and intense and the comedy was spot on most times I preferred it to the first onenPolkadot Milton Is dead sob sobnBloodsport Milton was with us whynHarley who is Milton]
Sentiment: POSITIVE (99.986%)
Review: [The Suicide Squad SPOILER Movie Review]
Sentiment: POSITIVE (50.850%)
Review: [The Suicide Squad Tamil Movie REVIEW via YouTube]
Sentiment: POSITIVE (93.022%)
Review: [Suicide Squad reviewnnreview YouTube JamesGunn movie critics Spoilers Peacemaker]
Sentiment: NEGATIVE (51.084%)
Review: [James Gunn somehow made a whopping big budget Troma movie and got WB to foot the bill Amazing]
Sentiment: NEGATIVE (100.000%)
Review: [Stargirl Season Spoilers ReviewSuicide Squad Box Office DC Allia via YouTubennFanboyClay and are live in minutes Come join us as we talk Stargirl TheSuicideSquad ReleaseTheAyerCut and some DC movie news]
Sentiment: NEGATIVE (99.949%)
Review: [Movie Review The Suicide Squad by vocalcreators]
Sentiment: POSITIVE (50.850%)
Review: [The Suicide Squad Movie Review NinjaRabbit via YouTube]
Sentiment: POSITIVE (93.022%)
Review: [The Suicide Squad The movie we NEEDED and DESERVED recap and review]
Sentiment: NEGATIVE (99.136%)
Review: [This was SO much better compared to the other Suicide Squad Had a blast watching this actually fun movie and with pretty emotional stuff toonMy review of The Suicide Squad on Letterboxd]
Sentiment: NEGATIVE (99.999%)
Review: [Last Week NeighborCole had the first WeeklyWatchParty Movie pick with Sling Blade nnThis week I picked In The Bedroom which Quadfathermft is not excited about nnWatch it on paramountplus and hear our Review on the next Days a Geek Podcast]
Sentiment: NEGATIVE (98.014%)

Convolutional Neural Networks Model:
Review: [This was SO much better compared to the other Suicide Squad Had a blast watching this actually fun movie and with pretty emotional stuff toonMy review of The Suicide Squad on Letterboxd]
Sentiment: NEGATIVE (51.905%)
Review: [NEGROMANCER Movie Review Suicide Squad Hell to Pay is Way]
Sentiment: NEGATIVE (50.688%)
Review: [FULL REVIEW The Suicide Squad movie MovieReview]
Sentiment: NEGATIVE (50.595%)
Review: [my letterboxd review of the suicide squad is up i hate that i use letterboxd now after i watch a movie]
Sentiment: NEGATIVE (53.234%)
Review: [In this episode of PodCapers Scott is joined by Francisco Andrade to talk about TheSuicideSquad Whats this Is this movie actually good PodernFamily review spoilers HarleyQuinn JamesGunn Bloodsport Peacemaker]
Sentiment: NEGATIVE (53.755%)
Review: [NowListeningnnfnnerds The Suicide Squad FN Movie]
Sentiment: NEGATIVE (50.688%)
Review: [The Suicide Squad Movie Review TheSuicideSquad]
Sentiment: NEGATIVE (50.688%)
Review: [JamesGunn can turn comic characters from the margins into cult movie heroes Career Russian roulette for Gunn and his squad has never seemed like suicide The whole comicbook galaxy is now under his changing guard We review DCComics TheSuicideSquad]
Sentiment: NEGATIVE (64.796%)
Review: [I Reads You IReadsYou Movie Review THE SUICIDE SQUAD]
Sentiment: NEGATIVE (50.688%)
Review: [Review NEGROMANCER Movie Review Suicide Squad Hell to Pay is Way]
Sentiment: NEGATIVE (50.688%)
Review: [this article just tells me you can write anything to justify anything and you dont even have to be compelling]
Sentiment: NEGATIVE (60.762%)
Review: [Blog The Highest Grossing Films That Critics Stand Give Suicide Squad Hope weekend saw the opening of The Suicide Squad the latest movie from DC Studios in the seemingly everlucrative comicbook movie era However audiences proved sluggish]
Sentiment: NEGATIVE (52.702%)
Review: [I finally posted my review for TheSuicideSquad check it out]
Sentiment: NEGATIVE (51.041%)
Review: [okay the suicide squad quick review from men good movie way better than the first one n FUNNY but also made me tear up n so dark amp sad amp wholesome but hilarious n margot robbie is everything n i believe im emotionally attached to a shark mutant creature thing]
Sentiment: NEGATIVE (53.181%)
Review: [The Gunn cut Cocked and aimed This is TheSuicideSquad reloaded by GuardiansOfTheGalaxy legendary director JamesGunn So lets arm up and meet this team of recruits standing in front of the stars and stripes like JoelKinnamans Rick Flag We review]
Sentiment: NEGATIVE (59.177%)
Review: [James Gunns The Suicide Squad is a wild gory and fun movie with actual stakes and likeable characters End of review nnTheSuicideSquad]
Sentiment: NEGATIVE (57.375%)
Review: [Movie ReviewnnThe Suicide Squad Bonkers wild an absolute blast]
Sentiment: POSITIVE (50.128%)
Review: [This isnt the DC studio I know Dark action adventure comedy with MargotRobbie JohnCena amp IdrisElba Flash Movie Review TheSuicideSquad via Moviejoltz]
Sentiment: NEGATIVE (56.546%)
Review: [Flash Movie Review The]
Sentiment: NEGATIVE (50.688%)
Review: [The DoOver Review The Suicide Squad Muscatine]
Sentiment: NEGATIVE (50.688%)
Review: [The DoOver Review The Suicide Squad Columbus]
Sentiment: NEGATIVE (50.688%)
Review: [Movie Minute SUICIDE SQUAD Review by paulsalfen]
Sentiment: NEGATIVE (50.688%)
Review: [James Gunns THE SUICIDE SQUAD Dont Get Too Attached But Enjoy The Ride Movie ReviewnnBy OGCinematichris TheSuicideSquad HBOMax]
Sentiment: NEGATIVE (50.688%)
Review: [NEGROMANCER Movie Review Suicide Squad Hell to Pay is Way]
Sentiment: NEGATIVE (50.688%)
Review: [A ridiculously fun over the top violent hilarious amp at times emotional action flick that further proves James Gunn really knows how to get it SuicideSquad jamesgunn DCEU MovieReview movie Review Letterboxd]
Sentiment: POSITIVE (50.642%)
Review: [The Suicide Squad proves that superhero films are at its best when it abandons the trytoohardtobefunny shtick and focus on the action that makes a superhero movie nnMy review of The Suicide Squad on Letterboxd]
Sentiment: NEGATIVE (63.298%)
Review: [FFP Reaction Review The Suicide SquadnnJoin BoneKingTV AdrianDudliness and DrRudeMD as they prepare for the impossible a fun SuicideSquad]
Sentiment: POSITIVE (51.328%)
Review: [In this episode of PodCapers Scott is joined by Francisco Andrade to talk about TheSuicideSquad Whats this Is this movie actually good PodernFamily review spoilers HarleyQuinn JamesGunn Bloodsport Peacemaker]
Sentiment: NEGATIVE (53.755%)
Review: [The Suicide Squad Bizarre Fun Movie Review YouTube]
Sentiment: NEGATIVE (50.688%)
Review: [Why is John Cena better in The Suicide Squad than Fast amp Furious Join our discussion]
Sentiment: NEGATIVE (50.688%)
Review: [New VideonThe Suicide Squad Movie]
Sentiment: NEGATIVE (50.688%)
Review: [Watch Th Best Bad Movie of All TimeThe Suicide Squad Review by TopTENN on YouTube]
Sentiment: NEGATIVE (50.688%)
Review: [I Reads You IReadsYou Movie Review THE SUICIDE SQUAD]
Sentiment: NEGATIVE (50.688%)
Review: [The Suicide squad Movie review Hindi via YouTubennMovieReview MovieReviews Review TheSuicideSquad movie Explainer]
Sentiment: NEGATIVE (52.191%)
Review: [The Suicide squad Movie review Hindi via YouTubennMovieReview MovieReviews Review TheSuicideSquad movie Explainer]
Sentiment: NEGATIVE (52.191%)
Review: [The Suicide Squad Movie Review via YouTube]
Sentiment: NEGATIVE (50.467%)
Review: [Review NEGROMANCER Movie Review Suicide Squad Hell to Pay is Way]
Sentiment: NEGATIVE (50.688%)
Review: [TheSuicideSquad is an awesome sequel to the original with a lot of heart emotion fun moments and a standout performance from MelchiorDaniela thanks to JamesGunnnnThe Suicide Squad is AWESOME Movie Review DCEU Movie Review A Ja via YouTube]
Sentiment: NEGATIVE (50.552%)
Review: [TheSuicideSquad is an awesome sequel to the original with a lot of heart emotion fun moments and a standout performance from MelchiorDaniela thanks to JamesGunnnnThe Suicide Squad is AWESOME Movie Review DCEU Movie Review A Ja via YouTube]
Sentiment: NEGATIVE (50.552%)
Review: [Did anybody like The Suicide SquadnnJudging from the responses I got on my those who didnt like it actually said they didnt like those who didnt watch it said they might want to watch those who like it hide]
Sentiment: NEGATIVE (63.151%)
Review: [Movie review Suicide Squad Overall I enjoyed it The action scenes are graphic at times and intense and the comedy was spot on most times I preferred it to the first onenPolkadot Milton Is dead sob sobnBloodsport Milton was with us whynHarley who is Milton]
Sentiment: NEGATIVE (52.379%)
Review: [The Suicide Squad SPOILER Movie Review]
Sentiment: NEGATIVE (50.688%)
Review: [The Suicide Squad Tamil Movie REVIEW via YouTube]
Sentiment: NEGATIVE (50.467%)
Review: [Suicide Squad reviewnnreview YouTube JamesGunn movie critics Spoilers Peacemaker]
Sentiment: NEGATIVE (50.195%)
Review: [James Gunn somehow made a whopping big budget Troma movie and got WB to foot the bill Amazing]
Sentiment: NEGATIVE (56.805%)
Review: [Stargirl Season Spoilers ReviewSuicide Squad Box Office DC Allia via YouTubennFanboyClay and are live in minutes Come join us as we talk Stargirl TheSuicideSquad ReleaseTheAyerCut and some DC movie news]
Sentiment: NEGATIVE (57.576%)
Review: [Movie Review The Suicide Squad by vocalcreators]
Sentiment: NEGATIVE (50.688%)
Review: [The Suicide Squad Movie Review NinjaRabbit via YouTube]
Sentiment: NEGATIVE (50.467%)
Review: [The Suicide Squad The movie we NEEDED and DESERVED recap and review]
Sentiment: POSITIVE (50.048%)
Review: [Last Week NeighborCole had the first WeeklyWatchParty Movie pick with Sling Blade nnThis week I picked In The Bedroom which Quadfathermft is not excited about nnWatch it on paramountplus and hear our Review on the next Days a Geek Podcast]
Sentiment: NEGATIVE (52.878%)
